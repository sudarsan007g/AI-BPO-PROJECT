---
title: AI BPO Voice Backend
emoji: 📞
colorFrom: blue
colorTo: green
sdk: docker
app_port: 7860
pinned: false
---

# Backend — deploy to Hugging Face Spaces (free)

1. Go to https://huggingface.co/join and create a free account (no card needed).
2. Click your profile → **New Space**.
   - Space name: e.g. `ai-bpo-backend`
   - License: any
   - **Space SDK: Docker** → template **Blank**
   - Visibility: Public
   - Click **Create Space**.
3. On the Space page, click **Files → Add file → Upload files**, and upload all 4 files
   from this `backend/` folder: `app.py`, `requirements.txt`, `Dockerfile`, `README.md`.
   (The `README.md` header above is required by Hugging Face - keep it at the top.)
4. Go to **Settings → Variables and secrets → New secret**:
   - Name: `GROQ_API_KEY`
   - Value: paste your key from https://console.groq.com/keys (free, no card)
   - Save.
5. Go back to the **App** tab and wait for the build to finish (2-5 minutes the first time).
6. Once it shows "Running", your backend URL is:
   `https://YOUR-USERNAME-ai-bpo-backend.hf.space`
   Test it by opening that URL - you should see `{"status": "AI BPO backend is running"}`.
7. Copy that URL into `frontend/script.js` as `BACKEND_URL`.

### Notes
- The free CPU Space sleeps after ~48h of no traffic and wakes up again (~30-60s cold start)
  the next time someone visits - this is normal for a free-tier demo.
- The Space's disk is **not persistent** across rebuilds, so `calls_log.xlsx` can reset if you
  re-upload files. For your final demo, click "Download call log" in the app before/after your
  demo to keep a permanent copy on your own laptop.
